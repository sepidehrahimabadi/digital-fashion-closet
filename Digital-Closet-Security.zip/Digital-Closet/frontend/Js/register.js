const doc = document;
const registerForm = doc.getElementById("register-form");
const usernameInput = doc.getElementById("register-username-input");
const emailInput = doc.getElementById("register-email-input");
const passwordInput = doc.getElementById("register-password-input");
const loginLink = doc.getElementById("login-link");
const message = doc.getElementById("message");
let registerFlag = false;

const registerUser = async () => {
  const user = {
    username: usernameInput.value,
    email: emailInput.value,
    password: passwordInput.value,
  };
  registerFlag = true;
  try {
    const res = await fetch("http://localhost:3000/api/auth/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(user),
    });
    if (!res.ok) {
      const errData = await res.json();
      message.textContent = errData.message || "Registration failed";
      message.style.color = "snow";
      message.style.background = "crimson";
      message.style.display = "inline-block";
      registerFlag = false;
      return;
    }
    const data = await res.json();
    if (data) {
      message.style.background = "seagreen";
      message.style.color = "snow";
      message.style.display = "inline-block";
      message.textContent = "Registration successful!";
      registerFlag = true;
      setTimeout(() => {
        window.location.replace("/login.html");
      }, 2000);
    }
  } catch (err) {
    console.error(err);
    message.textContent = "Network error. Please try again.";
    message.style.color = "snow";
    message.style.background = "crimson";
    message.style.display = "inline-block";
    registerFlag = false;
  }
};

registerForm.addEventListener("submit", (event) => {
  event.preventDefault();
  if (!registerFlag) {
    registerUser();
  }
});

loginLink.addEventListener("click", (event) => {
  event.preventDefault();
  window.location.replace("/login.html");
});
