const emailInput = document.getElementById("email");
const codeInput = document.getElementById("reset-code");
const newPasswordInput = document.getElementById("new-password");
const message = document.getElementById("message");

const stepEmail = document.getElementById("step-email");
const stepReset = document.getElementById("step-reset");

const sendCodeBtn = document.getElementById("send-code-btn");
const resetBtn = document.getElementById("reset-btn");

const showMessage = (text, isError) => {
  message.textContent = text;
  message.style.display = "block";
  message.style.color = "snow";
  message.style.background = isError ? "crimson" : "seagreen";
  message.style.padding = "10px";
  message.style.borderRadius = "5px";
};

sendCodeBtn.addEventListener("click", async () => {
  const email = emailInput.value;

  if (!email) {
    showMessage("Please enter your email", true);
    return;
  }

  try {
    const res = await fetch("http://localhost:3000/api/auth/request-reset", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });

    const data = await res.json();

    if (!res.ok) {
      showMessage(data.message || "Failed to send code", true);
      return;
    }

    showMessage("Code sent! Check your email.", false);
    stepEmail.style.display = "none";
    stepReset.style.display = "block";
  } catch (err) {
    console.error(err);
    showMessage("Server error. Please try again.", true);
  }
});

resetBtn.addEventListener("click", async () => {
  const email = emailInput.value;
  const code = codeInput.value;
  const newPassword = newPasswordInput.value;

  if (newPassword.length < 8) {
    showMessage("Password must be at least 8 characters", true);
    return;
  }

  try {
    const res = await fetch("http://localhost:3000/api/auth/reset-password", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, code, password: newPassword }),
    });

    const data = await res.json();

    if (!res.ok) {
      showMessage(data.message || "Reset failed", true);
      return;
    }

    showMessage("Password updated successfully! Redirecting to login...", false);
    setTimeout(() => {
      window.location.replace("/login.html");
    }, 2000);
  } catch (err) {
    console.error(err);
    showMessage("Server error. Please try again.", true);
  }
});