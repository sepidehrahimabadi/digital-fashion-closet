const doc = document;

const dashboardLink = doc.getElementById("dashboard-link");
const loginLink = doc.getElementById("login-link");
const registerLink = doc.getElementById("register-link");
const logoutBtn = doc.getElementById("logout-btn");
const loading = doc.querySelector(".loading");
const exampleBtn = document.getElementById("User-Guide-btn");
const exampleModal = document.getElementById("example-modal");
const closeExample = document.getElementById("close-example");

const checkUser = () => {
  const isLoggedIn = JSON.parse(
    localStorage.getItem("isUserLoggedIn") || "false"
  );

  if (isLoggedIn) {
    dashboardLink.style.cssText = "display: inline-block;";
    loginLink.style.cssText = "display: none;";
    registerLink.style.display = "none";
    logoutBtn.style.display = "inline-block";
  } else {
    dashboardLink.style.cssText = "display: none;";
    loginLink.style.cssText = "display: inline-block;";
    registerLink.style.display = "inline-block";
    logoutBtn.style.display = "none";
  }
};

logoutBtn.addEventListener("click", () => {
  localStorage.removeItem("isUserLoggedIn");
  localStorage.removeItem("isUserRegistered");
  localStorage.removeItem("userID");

  checkUser();
});

window.addEventListener("load", () => {
  checkUser();
  setTimeout(() => {
    loading.style.display = "none";
    window.document.body.style.overflowY = "auto";
  }, 500);
});

exampleBtn.addEventListener("click", () => {
  exampleModal.style.display = "flex";
});

closeExample.addEventListener("click", () => {
  exampleModal.style.display = "none";
});

exampleModal.addEventListener("click", (e) => {
  if (e.target === exampleModal) {
    exampleModal.style.display = "none";
  }
});
