const express = require("express");
const jwt = require("jsonwebtoken");
const xss = require("xss");
const router = express.Router();
const Item = require("../models/Item");
const User = require("../models/User");
const isAdmin = require("../middleware/isAdmin");

router.post("/", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ message: "No token provided" });
    }
    const token = authHeader.split(" ")[1];
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      return res.status(401).json({ message: "Invalid or expired token" });
    }
    const userId = decoded.id;
    const { username, onlineImage, isPublic } = req.body;
    const title = xss(req.body.title);
    const description = xss(req.body.description);
    if (isPublic) {
      const publicCount = await Item.countDocuments({ userId, isPublic: true });
      if (publicCount >= 4) {
        return res.status(400).json({ message: "You can only have up to 4 public moodboards." });
      }
    }
    const item = new Item({
      userId: String(userId).trim(),
      username,
      title,
      description,
      onlineImage: onlineImage || "",
      isPublic: !!isPublic,
    });
    await item.save();
    res.status(201).json(item);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error creating moodboard" });
  }
});

router.get("/", async (req, res) => {
  try {
    const items = await Item.find({ isPublic: true }).sort({ createdAt: -1 });
    res.json(items);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get("/user/:userId", async (req, res) => {
  try {
    const items = await Item.find({ userId: req.params.userId }).sort({ createdAt: -1 });
    res.json(items);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get("/all", isAdmin, async (req, res) => {
  try {
    const items = await Item.find().sort({ createdAt: -1 });
    res.json(items);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ message: "No token provided" });
    }
    const token = authHeader.split(" ")[1];
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      return res.status(401).json({ message: "Invalid or expired token" });
    }
    const userId = decoded.id;
    const item = await Item.findById(req.params.id);
    if (!item) return res.status(404).json({ message: "Moodboard not found" });
    const user = await User.findById(userId);
    const isOwner = item.userId === String(userId);
    const isAdminUser = user && user.role === "admin";
    if (!isOwner && !isAdminUser) {
      return res.status(403).json({ message: "Not authorized" });
    }
    await Item.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ message: "No token provided" });
    }
    const token = authHeader.split(" ")[1];
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      return res.status(401).json({ message: "Invalid or expired token" });
    }
    const userId = decoded.id;
    const item = await Item.findById(req.params.id);
    if (!item) return res.status(404).json({ message: "Not found" });
    const user = await User.findById(userId);
    const isOwner = item.userId === String(userId);
    const isAdminUser = user && user.role === "admin";
    if (!isOwner && !isAdminUser) {
      return res.status(403).json({ message: "Not authorized" });
    }
    const updates = { ...req.body };
    if (updates.title) updates.title = xss(updates.title);
    if (updates.description) updates.description = xss(updates.description);
    const updatedItem = await Item.findByIdAndUpdate(req.params.id, updates, { new: true });
    res.json(updatedItem);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;