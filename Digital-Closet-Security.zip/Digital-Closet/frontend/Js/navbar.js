{
  const getRole = () => localStorage.getItem("role");
  const isLoggedIn = JSON.parse(localStorage.getItem("isUserLoggedIn") || "false");
  const adminLink = document.getElementById("admin-link");
  const loginLink = document.getElementById("login-link");
  const registerLink = document.getElementById("register-link");
  const logoutBtn = document.getElementById("logout-btn");

  if (!isLoggedIn) {
    if (adminLink) adminLink.style.display = "none";
    if (logoutBtn) logoutBtn.style.display = "none";
  } else {
    if (loginLink) loginLink.style.display = "none";
    if (registerLink) registerLink.style.display = "none";
    if (logoutBtn) logoutBtn.style.display = "inline-block";
    if (adminLink) {
      adminLink.style.display = getRole() === "admin" ? "inline-block" : "none";
    }
  }

  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      localStorage.clear();
      window.location.replace("/index.html");
    });
  }
}