const doc = document;

const userLoggedIn = JSON.parse(localStorage.getItem("isUserLoggedIn") || "false");
const userRole = localStorage.getItem("role");

if (window.location.pathname.includes("admin") && userRole !== "admin") {
  window.location.replace("/index.html");
}

const dashboardLink = doc.getElementById("dashboard-link");
const loginLink = doc.getElementById("login-link");
const registerLink = doc.getElementById("register-link");
const logoutBtn = doc.getElementById("logout-btn");

const dashboardGrid = doc.querySelector(".dashboard-grid");
const loading = doc.querySelector(".loading");
const message = doc.getElementById("message");

const checkUser = () => {
  if (!userLoggedIn) {
    window.location.replace("/login.html");
  }
};

const getMoodBoards = async () => {
  const userId = localStorage.getItem("userID");

  if (!userId) {
    message.style.display = "block";
    message.textContent = "No user found";
    return;
  }

  loading.style.display = "flex";
  message.style.display = "none";
  dashboardGrid.style.display = "none";

  try {
    const res = await fetch(`http://localhost:3000/api/items/user/${userId}`);

    if (!res.ok) throw new Error("Request failed");

    const data = await res.json();

    if (!data.length) {
      message.style.display = "block";
      message.textContent = "No Moodboards Found";
      return;
    }

    dashboardGrid.innerHTML = "";

    data.forEach((item) => {
      dashboardGrid.insertAdjacentHTML("beforeend", `
        <div class="dashboard-card">
          <img src="${item.onlineImage}" />
          <div class="card-body">
            <h3 class="card-title">${item.title}</h3>
            <p class="card-description">${item.description}</p>
            <div class="card-footer">
              <div class="card-actions">
                <button class="btn-edit"
                  data-id="${item._id}"
                  data-title="${item.title.replace(/"/g, '&quot;')}"
                  data-desc="${item.description.replace(/"/g, '&quot;')}">
                  <i class="bi bi-pencil"></i>
                </button>
                <button class="btn-delete" data-id="${item._id}">
                  <i class="bi bi-trash"></i>
                </button>
                <button class="btn-public"
                  data-id="${item._id}"
                  data-public="${item.isPublic}">
                  ${item.isPublic ? "Make Private" : "Make Public"}
                </button>
              </div>
            </div>
          </div>
        </div>
      `);
    });

  } catch (err) {
    message.style.display = "block";
    message.textContent = "Server error. Try again.";
  } finally {
    setTimeout(() => {
      loading.style.display = "none";
      dashboardGrid.style.display = "flex";
      document.body.style.overflowY = "auto";
    }, 500); 
  }
};

const removeMoodboard = async (id) => {
  try {
      const res = await fetch(`http://localhost:3000/api/items/${id}`, {
        method: "DELETE",
        headers: { Authorization: "Bearer " + localStorage.getItem("token") }
      });
    if (!res.ok) return;
    const data = await res.json();
    if (data.success) await getMoodBoards();
  } catch (err) {
    console.error(err);
  }
};

const editMoodboard = async (id, title, description) => {
  const newTitle = prompt("Edit title:", title);
  const newDescription = prompt("Edit description:", description);
  if (!newTitle || !newDescription) return;
  try {
    const res = await fetch(`http://localhost:3000/api/items/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("token")
      },
      body: JSON.stringify({ title: newTitle, description: newDescription }),
    });
    if (!res.ok) { alert("Update failed"); return; }
    getMoodBoards();
  } catch (err) {
    console.error(err);
  }
};

const togglePublic = async (id, currentStatus) => {
  try {
    const res = await fetch(`http://localhost:3000/api/items/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("token")
      },
      body: JSON.stringify({ isPublic: !currentStatus }),
    });
    if (!res.ok) { alert("Update failed"); return; }
    getMoodBoards();
  } catch (err) {
    console.error(err);
  }
};

const saveItem = async (id) => {
  await fetch(`http://localhost:3000/api/user/save/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + localStorage.getItem("token"),
    },
  });
};

window.addEventListener("load", () => {
  checkUser();
  getMoodBoards();

  if (dashboardLink && loginLink && registerLink && logoutBtn) {
    if (userLoggedIn) {
      dashboardLink.style.display = "inline-block";
      loginLink.style.display = "none";
      registerLink.style.display = "none";
      logoutBtn.style.display = "inline-block";
    } else {
      dashboardLink.style.display = "none";
      loginLink.style.display = "inline-block";
      registerLink.style.display = "inline-block";
      logoutBtn.style.display = "none";
    }
  }

  // ================= BUTTON CLICKS =================
  document.addEventListener("click", (e) => {
    const editBtn = e.target.closest(".btn-edit");
    const deleteBtn = e.target.closest(".btn-delete");
    const publicBtn = e.target.closest(".btn-public");

    if (editBtn) editMoodboard(editBtn.dataset.id, editBtn.dataset.title, editBtn.dataset.desc);
    if (deleteBtn) removeMoodboard(deleteBtn.dataset.id);
    if (publicBtn) togglePublic(publicBtn.dataset.id, publicBtn.dataset.public === "true");
  });

  // ================= MODAL =================
  const modal = document.getElementById("image-modal");
  const modalImg = document.getElementById("modal-img");
  const closeBtn = document.querySelector(".close");

  document.addEventListener("click", (e) => {
    if (
      e.target.closest(".btn-edit") ||
      e.target.closest(".btn-delete") ||
      e.target.closest(".btn-public")
    ) return;
    const img = e.target.closest("img");
    if (!img) return;
    modal.style.display = "flex";
    modalImg.src = img.src;
  });

  closeBtn.addEventListener("click", () => {
    modal.style.display = "none";
  });

  modal.addEventListener("click", (e) => {
    if (e.target === modal) modal.style.display = "none";
  });

  // ================= ADMIN LINK =================
  const adminLink = document.getElementById("admin-link");
  if (adminLink) {
    const currentRole = localStorage.getItem("role");
    adminLink.style.display = currentRole === "admin" ? "inline-block" : "none";
    adminLink.addEventListener("click", (e) => {
      if (currentRole !== "admin") {
        e.preventDefault();
        alert("You are not admin");
      }
    });
  }
});
