require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const helmet = require("helmet"); // SECURITY: adds safe HTTP headers
require("./db");
const authRoutes = require("./routes/auth");
const itemRoutes = require("./routes/items");
const userRoutes = require("./routes/user");
const app = express();

//middleware
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        imgSrc: ["'self'", "data:", "https:"], // SECURITY: allow images from my site + any https source (needed since moodboards use external image URLs)
        scriptSrc: ["'self'", "'unsafe-inline'"],
        scriptSrcAttr: ["'unsafe-inline'"], // SECURITY: allow inline onclick handlers (used in dynamically rendered buttons)
      },
    },
  })
); // SECURITY: apply Helmet's safety headers, customized to allow external images
app.use(cors());
app.use(express.json());


// Routes
app.use("/api/auth", authRoutes);
app.use("/api/items", itemRoutes);
app.use("/api/user", userRoutes);

//frontend files
app.use(express.static(path.join(__dirname, "../frontend")));
app.use(express.static(path.join(__dirname, "public")));
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend", "index.html"));
});

// Start server
app.listen(3000, () => console.log("Server running on http://localhost:3000"));