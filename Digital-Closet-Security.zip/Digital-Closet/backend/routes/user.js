const express = require("express");
const jwt = require("jsonwebtoken");
const router = express.Router();
const User = require("../models/User");
const Item = require("../models/Item");
const isAdmin = require("../middleware/isAdmin"); 

// SAVE / UNSAVE ITEM
router.put("/save/:itemId", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ message: "No token provided" });
    }

    const token = authHeader.split(" ")[1];
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      return res.status(401).json({ message: "Invalid or expired token" });
    }

    const userId = decoded.id;
    const itemId = req.params.itemId;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const exists = user.savedItems.some(
      (id) => id.toString() === itemId
    );

    if (exists) {
      user.savedItems.pull(itemId);
    } else {
      user.savedItems.push(itemId);
    }

    await user.save();

    res.json({
      success: true,
      saved: !exists
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

router.get("/saved/:userId", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ message: "No token provided" });
    }

    const token = authHeader.split(" ")[1];
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      return res.status(401).json({ message: "Invalid or expired token" });
    }

    if (decoded.id !== req.params.userId) {
      return res.status(403).json({ message: "Not authorized to view this list" });
    }

    const user = await User.findById(req.params.userId).populate("savedItems");
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json(user.savedItems);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

router.get("/admin/user/:id", isAdmin, async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select("-password");

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const moodboardCount = await Item.countDocuments({ userId: user._id });

    res.json({
      user,
      moodboardCount
    });

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get("/admin/all", isAdmin, async (req, res) => {
  try {
    const users = await User.find().select("-password");
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});


router.put("/admin/make-admin/:id", isAdmin, async (req, res) => {
  try {
    const targetUser = await User.findById(req.params.id);
    if (!targetUser) return res.status(404).json({ message: "User not found" });

    // nobody can change root admin
    if (targetUser.isRootAdmin) {
      return res.status(403).json({ message: "Cannot change root admin role" });
    }

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { role: req.body.role },
      { new: true }
    ).select("-password");

    res.json(user);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;