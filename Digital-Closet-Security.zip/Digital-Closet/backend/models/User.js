const mongoose = require("../db");

const UserSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    trim: true
  },

  email: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },

  password: {
    type: String,
    required: true
  },

  role: {
    type: String,
    enum: ["user", "admin"],
    default: "user"
  },
  isRootAdmin:{
    type:Boolean,
    default:false
  },

  savedItems:[
    {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Item"
    }
  ],

  failedAttempts: {
    type: Number,
    default: 0,
  } ,

  lockUntil: {
    type: Date,
    default: null,
  },

  createdAt: {
    type: Date,

    default: Date.now
  },

  resetCode: {
    type: String,
    default: null,
  },
  resetCodeExpires: {
    type: Date,
    default: null,
  }

  });


module.exports = mongoose.model("User", UserSchema);
