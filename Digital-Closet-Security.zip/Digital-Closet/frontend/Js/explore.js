const doc = document;

const dashboardLink = doc.getElementById("dashboard-link");
const loginLink = doc.getElementById("login-link");
const registerLink = doc.getElementById("register-link");
const logoutBtn = doc.getElementById("logout-btn");
const message = doc.getElementById("message");
const moodboardsStatus = doc.getElementById("moodboards-status");
const moodboardsParent = doc.querySelector(".explore-grid");
const loading = doc.querySelector(".loading");

const searchInput = doc.getElementById("search-input");
let allMoodboards = [];

const addMoodboardToDOM = (data) => {
  moodboardsParent.style.display = "none";
  moodboardsStatus.style.display = "none";

  moodboardsParent.innerHTML = "";
  data.forEach((item) => {
    moodboardsParent.insertAdjacentHTML(
      "beforeend",
      `
<div class="moodboard-card">
    <img src="${item.onlineImage}" alt="${item.title}">
    <h3>${item.title}</h3>
    <p>${item.description}</p>
    <span><i class="bi bi-person"></i> ${item.username}</span>
    <button class="btn-save" data-id="${item._id}">
         Save
    </button>
</div>
        
    `
    );
  });

  setTimeout(() => {
    moodboardsStatus.style.display = "none";
    moodboardsParent.style.display = "grid";
  }, 1500);
};

const checkUser = () => {
  const isLoggedIn = JSON.parse(
    localStorage.getItem("isUserLoggedIn") || false
  );

  if (isLoggedIn) {
    dashboardLink.style.cssText = "display: inline-block;";
    loginLink.style.cssText = "display: none;";
    registerLink.style.display = "none";
    logoutBtn.style.display = "inline-block";
  } else {
    dashboardLink.style.cssText = "display: none;";
    loginLink.style.cssText = "display: inline-block;";
    registerLink.style.display = "inline-block";
    logoutBtn.style.display = "none";
  }
};

const getMoodBoards = async () => {
  try {
    moodboardsStatus.style.display = "block";
    moodboardsParent.style.display = "none";
    moodboardsStatus.textContent = "Loading...";
    const res = await fetch("http://localhost:3000/api/items");

    if (!res.ok) {
      moodboardsStatus.textContent =
        "Oops! Could not load moodboards. Please try again.";
      moodboardsStatus.style.color = "red";
      return;
    }

    const data = await res.json();

    if (data && data.length > 0) {
      allMoodboards = data;
      addMoodboardToDOM(data);
    } else {
      moodboardsStatus.insertAdjacentHTML(
        "beforeend",
        `
            <div class="moodboard-card">
                <img src="https://images.unsplash.com/photo-1503341455253-b2e723bb3dbb?auto=format&fit=crop&w=800&q=80"
                    alt="Dark editorial fashion">
                <h3>Soft Minimal Vibes</h3>
                <p>A serene moodboard showcasing soft tones and clean lines for everyday elegance.</p>
                <span><i class="bi bi-person"></i> Sara</span>
            </div>

            <div class="moodboard-card">
                <img src="https://images.unsplash.com/photo-1502716119720-b23a93e5fe1b?auto=format&fit=crop&w=400&q=70"
                    alt="Street fashion aesthetic">
                <h3>Urban Street Style</h3>
                <p>Bold contrasts and casual layers capturing the spirit of contemporary city fashion.</p>
                <span><i class="bi bi-person"></i> Alex</span>
            </div>

            <div class="moodboard-card">
                <img src="https://images.unsplash.com/photo-1519744792095-2f2205e87b6f?auto=format&fit=crop&w=400&q=70"
                    alt="Neutral tones fashion moodboard">
                <h3>Timeless Neutrals</h3>
                <p>Classic neutral palettes layered for effortless and versatile outfits.</p>
                <span><i class="bi bi-person"></i> Mina</span>
            </div>

            <div class="moodboard-card">
                <img src="https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=400&q=70"
                    alt="Editorial fashion concept">
                <h3>Dark Editorial Chic</h3>
                <p>High-fashion editorial concepts with moody tones and dramatic silhouettes.</p>
                <span><i class="bi bi-person"></i> John</span>
            </div>  
      `
      );
      return;
    }
  } catch (err) {
    console.error(err);
    moodboardsStatus.style.display = "block";
    moodboardsParent.style.display = "none";
    moodboardsStatus.textContent = "Server error. Please try again.";
  }
};

logoutBtn.addEventListener("click", () => {
  localStorage.removeItem("isUserLoggedIn");
  localStorage.removeItem("isUserRegistered");
  localStorage.removeItem("userID");

  checkUser();
});

window.addEventListener("load", () => {
  loading.style.display = "flex";
  moodboardsStatus.style.display = "none"; 
  moodboardsParent.style.display = "none";
  checkUser();
  getMoodBoards();
  setTimeout(() => {
    loading.style.display = "none";
    window.document.body.style.overflowY = "auto";
  }, 500);
});

searchInput.addEventListener("input", () => {
  const value = searchInput.value.toLowerCase();

  const filteredMoodboards = allMoodboards.filter((item) => {
    return (
      item.title.toLowerCase().includes(value) ||
      item.username.toLowerCase().includes(value)
    );
  });

  addMoodboardToDOM(filteredMoodboards);
});

const modal = document.getElementById("image-modal");
const modalImg = document.getElementById("modal-img");
const closeBtn = document.querySelector(".close");

// OPEN IMAGE (click card)
document.addEventListener("click", (e) => {

  //SAVE BUTTON
  const saveBtn = e.target.closest(".btn-save");
  if (saveBtn) {
    saveItem(saveBtn.dataset.id);
    return;
  }

  // EDIT / DELETE / PUBLIC
  if (
    e.target.closest(".btn-edit") ||
    e.target.closest(".btn-delete") ||
    e.target.closest(".btn-public")
  ) {
    return;
  }

  // IMAGE MODAL
  const img = e.target.closest("img");
  if (!img) return;

  modal.style.display = "flex";
  modalImg.src = img.src;
});



// CLOSE x
closeBtn.addEventListener("click", () => {
  modal.style.display = "none";
});

// CLOSE (click outside)
modal.addEventListener("click", (e) => {
  if (e.target === modal) {
    modal.style.display = "none";
  }
});

const saveItem = async (id) => {
  const token = localStorage.getItem("token");

  if (!token) {
    alert("You must login first");
    return;
  }

  try {
    const res = await fetch(`http://localhost:3000/api/user/save/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
    });

    const data = await res.json();
    const btn = document.querySelector(`.btn-save[data-id="${id}"]`);
    if (btn) btn.textContent = data.saved ? "✔️ Saved" : "Save";
  } catch (err) {
    console.error(err);
  }
};