module.exports = function redirectIfLoggedIn(req, res, next) {
  if (req.user) {
    return res.status(403).json({ message: "You are already logged in." });
  }
  next();
};
