const doc = document;

const loginForm = doc.getElementById("login-form");
const emailInput = doc.getElementById("login-email-input");
const passwordInput = doc.getElementById("login-password-input");
const message = doc.getElementById("message");
let timer;

let loginFlag = false;

const loginUser = async () => {
  const user = {
    email: emailInput.value,
    password: passwordInput.value,
  };
  loginFlag = true;

  try {
    console.log(user);
    const res = await fetch("http://localhost:3000/api/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(user),
    });

    if (!res.ok) {
      const errData = await res.json();
      message.style.color = "snow";
      if (errData.remainingSeconds) {
        let timeLeft = errData.remainingSeconds;

        clearInterval(timer);

        timer = setInterval(() => {
          const minutes = Math.floor(timeLeft / 60);
          const seconds = timeLeft % 60;

          message.textContent =
            `Account locked. Try again in ${minutes}:${seconds
              .toString()
              .padStart(2, "0")}`;

          timeLeft--;

          if (timeLeft < 0) {
            clearInterval(timer);
            message.textContent = "You can try logging in again.";
          }
        }, 1000);

      } else {
        message.textContent = errData.message || "Login failed";
      }
      message.style.background = "crimson";
      message.style.display = "inline-block";
      loginFlag = true;
      return;
    }

    const data = await res.json();
    console.log("LOGIN RESPONSE:", data);

    if (data.success === true) {
      loginFlag = true;

      localStorage.setItem("isUserLoggedIn", true);
      localStorage.setItem("userID", data.id);
      localStorage.setItem("role", data.role);
      localStorage.setItem("loginTime", Date.now());
      localStorage.setItem("token", data.token);

      message.style.background = "seagreen";
      message.style.color = "snow";
      message.style.display = "inline-block";
      message.textContent = "Login successful!";

      setTimeout(() => {
        if (data.role === "admin") {
          window.location.replace("/admin.html");
        } else {
          window.location.replace("/index.html");
        }
      }, 2000);
    } else {
      message.style.color = "snow";
      message.style.background = "crimson";
      message.style.display = "inline-block";
      message.textContent = data.message || "Login failed";
      loginFlag = false;
    }
  } catch (err) {
    console.error(err);
    message.textContent = "Network error. Please try again.";
    message.style.color = "snow";
    message.style.background = "crimson";
    message.style.display = "inline-block";
    loginFlag = false;
  }
};

loginForm.addEventListener("submit", (event) => {
  event.preventDefault();

  loginUser();
});



const checkUser = () => {
  const isLoggedIn = JSON.parse(
    localStorage.getItem("isUserLoggedIn") || "false"
  );
  console.log(isLoggedIn);
  if (isLoggedIn) {
    window.location.replace("/index.html");
  }

};

window.addEventListener("load", () => {
  checkUser();

const loginTime = Number(localStorage.getItem("loginTime"));

if (loginTime && Date.now() - loginTime > 3600000) {
  localStorage.clear();
  window.location.reload();
}

});
