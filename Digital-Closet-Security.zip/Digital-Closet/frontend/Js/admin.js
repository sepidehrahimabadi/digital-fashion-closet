const msg = document.getElementById("message");
if (!window.__isAdmin) {
  document.querySelector("nav").style.display = "none";
  document.querySelector("h1").style.display = "none";
}
const searchInput = document.getElementById("searchInput");
let allItems = [];

const modal = document.getElementById("image-modal");
const modalImg = document.getElementById("modal-img");
const closeBtn = document.querySelector(".close");
const container = document.getElementById("admin-container");
const userDetails = document.getElementById("user-details");
const loading = document.querySelector(".loading");

const toggleUsersBtn = document.getElementById("toggle-users-btn");
const usersListContainer = document.getElementById("users-list-container");
let usersVisible = false;
let usersLoaded = false;

toggleUsersBtn.addEventListener("click", async () => {
  if (!usersVisible) {
    if (!usersLoaded) {
      await loadUsers();
      usersLoaded = true;
    }
    usersListContainer.style.display = "block";
    toggleUsersBtn.textContent = "👥 Hide Users";
    usersVisible = true;
  } else {
    usersListContainer.style.display = "none";
    toggleUsersBtn.textContent = "👥 Show Users";
    usersVisible = false;
  }
});

if (!window.__isAdmin) {
  const isLoggedIn = JSON.parse(localStorage.getItem("isUserLoggedIn") || "false");
  msg.textContent = !isLoggedIn
    ? " You need to be logged in to access this page."
    : " Oops! This page is for admins only.";
  msg.style.display = "block";
  setTimeout(() => window.location.replace("/index.html"), 2000);
} else {
  window.addEventListener("load", async () => {
    loading.style.display = "flex";
    await loadAll();
    loading.style.display = "none";
    container.style.display = "grid";
  });
}

// LOAD all

const loadAll = async () => {
  try {
    container.innerHTML = "";
    const res = await fetch("http://localhost:3000/api/items/all", {
      headers: {
        Authorization: "Bearer " + localStorage.getItem("token")
      }
    });
    const data = await res.json();
    allItems = data;
    data.forEach((item) => {
      container.innerHTML += `
        <div class="card">
          <img src="${item.onlineImage}" />
          <div class="card-body">
            <h2>${item.title}</h2>
            <p>${item.description}</p>
            <p><b>User:</b> ${item.username}</p>
            <p><b>Status:</b> ${item.isPublic ? "Public" : "Private"}</p>
            <div class="card-actions">
              <button class="btn-edit"
                data-id="${item._id}"
                data-title="${item.title.replace(/"/g, '&quot;')}"
                data-desc="${item.description.replace(/"/g, '&quot;')}">
                Edit
              </button>
              <button class="btn-delete"
                data-id="${item._id}">
                Delete
              </button>
              <button class="btn-public"
                data-id="${item._id}"
                data-public="${item.isPublic}">
                ${item.isPublic ? "Make Private" : "Make Public"}
              </button>
            </div>
          </div>
        </div>
      `;
    });

  } catch (err) {
    container.innerHTML = "<p>Error loading data</p>";
    console.error(err);
  }
  };
  

// ACTIONS

const deleteItem = async (id) => {
  try {
    await fetch(`http://localhost:3000/api/items/${id}`, {
      method: "DELETE",
      headers: { Authorization: "Bearer " + localStorage.getItem("token") }
    });
    loadAll();
  } catch (err) {
    console.error(err);
  }
};

const editItem = async (id, title, description) => {
  const newTitle = prompt("New title:", title);
  const newDesc = prompt("New description:", description);
  if (!newTitle || !newDesc) return;
  try {
    await fetch(`http://localhost:3000/api/items/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
         Authorization: "Bearer " + localStorage.getItem("token")
      },
      body: JSON.stringify({ title: newTitle, description: newDesc })
    });
    loadAll();
  } catch (err) {
    console.error(err);
  }
};

const togglePublic = async (id, state) => {
  try {
    await fetch(`http://localhost:3000/api/items/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("token")
      },
      body: JSON.stringify({ isPublic: !state })
    });
    loadAll();
  } catch (err) {
    console.error(err);
  }
};

const toggleAdminRole = async (id, currentRole) => {
  const newRole = currentRole === "admin" ? "user" : "admin";
  try {
    await fetch(`http://localhost:3000/api/user/admin/make-admin/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("token")
      },
      body: JSON.stringify({ role: newRole })
    });
    getUserDetails(id);
  } catch (err) {
    console.error(err);
  }
};

const getUserDetails = async (id) => {
  try {
      const res = await fetch(`http://localhost:3000/api/user/admin/user/${id}`, {
        headers: { Authorization: "Bearer " + localStorage.getItem("token") }
    });
    const data = await res.json();
    usersListContainer.style.display = "none";
    userDetails.innerHTML = `
      <div class="user-card">
        <button class="btn-back">← Back</button>
        <h2>${data.user.username}</h2>
        <p>User ID: ${data.user._id}</p>
        <p>Role: ${data.user.role}</p>
        <p>Joined: ${new Date(data.user.createdAt).toLocaleDateString()}</p>
        <h3>Total Moodboards: ${data.moodboardCount}</h3>
        ${data.user.isRootAdmin ? "" : `
          <button class="btn-toggle-admin" data-id="${data.user._id}" data-role="${data.user.role}">
            ${data.user.role === "admin" ? "⬇️ Remove Admin" : "⬆️ Make Admin"}
          </button>
        `}
      </div>
    `;
  } catch (err) {
    console.error(err);
    userDetails.innerHTML = "<p>Error loading user</p>";
  }
};

const loadUsers = async () => {
  try {
    const res = await fetch("http://localhost:3000/api/user/admin/all", {
      headers: { Authorization: "Bearer " + localStorage.getItem("token")}
    });
    const data = await res.json();
    usersListContainer.innerHTML = `
      <div class="users-list">
        <h3>All Users (${data.length})</h3>
        ${data.map(user => `
          <button class="user-item" data-id="${user._id}">
            👤 ${user.username}
          </button>
        `).join("")}
      </div>
    `;
  } catch (err) {
    console.error(err);
  }
};


document.addEventListener("click", (e) => {

const backBtn = e.target.closest(".btn-back");
if (backBtn) {
  userDetails.innerHTML = "";
  usersListContainer.style.display = "block";
  return;
}

  const userBtn = e.target.closest(".user-item");
  if (userBtn) {
    getUserDetails(userBtn.dataset.id);
    return;
  }

  const editBtn = e.target.closest(".btn-edit");
  if (editBtn) {
    editItem(editBtn.dataset.id, editBtn.dataset.title, editBtn.dataset.desc);
    return;
  }

  const deleteBtn = e.target.closest(".btn-delete");
  if (deleteBtn) {
    deleteItem(deleteBtn.dataset.id);
    return;
  }

  const publicBtn = e.target.closest(".btn-public");
  if (publicBtn) {
    togglePublic(publicBtn.dataset.id, publicBtn.dataset.public === "true");
    return;
  }

  const toggleAdminBtn = e.target.closest(".btn-toggle-admin");
  if (toggleAdminBtn) {
    toggleAdminRole(toggleAdminBtn.dataset.id, toggleAdminBtn.dataset.role);
    return;
  }

});

closeBtn.addEventListener("click", () => modal.style.display = "none");
modal.addEventListener("click", (e) => {
  if (e.target === modal) modal.style.display = "none";
});
  // OPEN IMAGE (click card)
document.addEventListener("click", (e) => {

  if (
    e.target.closest(".btn-edit") ||
    e.target.closest(".btn-delete") ||
    e.target.closest(".btn-public")
  ) 
    return;

  const img = e.target.closest("img");
  if (!img) return;

  modal.style.display = "flex";
  modalImg.src = img.src;
});


searchInput.addEventListener("input", () => {
  const value = searchInput.value.toLowerCase();

  const filtered = allItems.filter((item) => {
    return (
      item.title.toLowerCase().includes(value) ||
      item.username.toLowerCase().includes(value) ||
      item._id.toLowerCase().includes(value)
    );
  });

container.innerHTML = "";

filtered.forEach((item) => {
  container.innerHTML += `
    <div class="card">
      <img src="${item.onlineImage}" />
      <div class="card-body">
        <h2>${item.title}</h2>
        <p>${item.description}</p>
        <p><b>User:</b> ${item.username}</p>
        <p><b>Status:</b> ${item.isPublic ? "Public" : "Private"}</p>

        <div class="card-actions">
          <button class="btn-edit"
            data-id="${item._id}"
            data-title="${item.title.replace(/"/g, '&quot;')}"
            data-desc="${item.description.replace(/"/g, '&quot;')}">
            Edit
          </button>

          <button class="btn-delete"
            data-id="${item._id}">
            Delete
          </button>

          <button class="btn-public"
            data-id="${item._id}"
            data-public="${item.isPublic}">
            ${item.isPublic ? "Make Private" : "Make Public"}
          </button>
        </div>
      </div>
    </div>
  `;
});
});

