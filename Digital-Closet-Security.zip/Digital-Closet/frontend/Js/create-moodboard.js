const doc = document;

const dashboardLink = doc.getElementById("dashboard-link");
const loginLink = doc.getElementById("login-link");
const registerLink = doc.getElementById("register-link");
const logoutBtn = doc.getElementById("logout-btn");

const form = doc.querySelector(".moodboard-form");
const title = doc.getElementById("title");
const description = doc.getElementById("description");
const onlineImage = doc.getElementById("online-image");
const publicRadio = doc.getElementById("public-radio");
const message = doc.getElementById("message");

let createFlag = false;

const checkUser = () => {
  const isLoggedIn = JSON.parse(
    localStorage.getItem("isUserLoggedIn") || "false"
  );

  if (isLoggedIn) {
    dashboardLink.style.cssText = "display: inline-block;";
    loginLink.style.cssText = "display: none;";
    registerLink.style.display = "none";
    logoutBtn.style.display = "inline-block";
  } else {
    dashboardLink.style.cssText = "display: none;";
    loginLink.style.cssText = "display: inline-block;";
    registerLink.style.display = "inline-block";
    logoutBtn.style.display = "none";

    window.location.replace("/login.html");
  }
};

const createNewMoodboard = async (userData) => {
  const moodboard = {
    username: userData.username,
    title: title.value,
    description: description.value,
    onlineImage: onlineImage.value,
    isPublic: publicRadio.checked,
  };
  createFlag = true;
  try {
    const res = await fetch("http://localhost:3000/api/items", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
      body: JSON.stringify(moodboard),
    });

    if (!res.ok) {
      const errData = await res.json();
      message.style.display = "block";
      message.style.color = "red";
      message.textContent =
        errData.message || "Something went wrong while creating the moodboard.";
      createFlag = false;
      return;
    }

    const postData = await res.json();

    if (postData) {
      createFlag = true;
      message.style.display = "block";
      message.style.color = "seagreen";
      message.textContent = "The moodboard has been created successfully!";
      setTimeout(() => {
        window.location.replace("/dashboard.html");
      }, 1500);
    }
  } catch (err) {
    console.error(err);
    message.style.display = "block";
    message.style.color = "red";
    message.textContent = "Server error. Try again.";
    createFlag = false;
  }
};

const getUserInfo = async () => {
  const userId = localStorage.getItem("userID");

  if (userId) {
    try {
      const res = await fetch(`http://localhost:3000/api/auth/user/${userId}`);

      if (!res.ok) {
        message.style.display = "block";
        message.style.color = "red";
        message.textContent = "Failed to fetch user info. Try again.";
        return;
      }

      const data = await res.json();
      createNewMoodboard(data.user);
    } catch (err) {
      console.error(err);
      message.style.display = "block";
      message.style.color = "red";
      message.textContent = "Server error. Please try again.";
    }
  }
};

form.addEventListener("submit", (event) => {
  event.preventDefault();

  if (!createFlag) {
    getUserInfo();
  }
});

logoutBtn.addEventListener("click", () => {
  localStorage.removeItem("isUserLoggedIn");
  localStorage.removeItem("isUserRegistered");
  localStorage.removeItem("userID");

  checkUser();
});

window.addEventListener("load", () => {
  checkUser();
});
