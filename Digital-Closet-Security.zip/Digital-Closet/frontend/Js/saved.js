const container = document.getElementById("saved-container");
const loading = document.querySelector(".loading");

const loadSaved = async () => {
  const userId = localStorage.getItem("userID");
  container.style.display = "none";
  loading.style.display = "flex";

  try {
    const res = await fetch(`http://localhost:3000/api/user/saved/${userId}`, {
      headers: { Authorization: "Bearer " + localStorage.getItem("token") },
    });
    const data = await res.json();

    if (!Array.isArray(data) || data.length === 0) {
      container.innerHTML = "<p>No saved items yet</p>";
    } else {
      container.innerHTML = "";
      data.forEach(item => {
          container.innerHTML += `
            <div class="card">
              <div>
                <img src="${item.onlineImage}" />
                <h3 class="card-title">${item.title}</h3>
                <p class="card-description">${item.description}</p>
                <p class="card-user"><i class="bi bi-person"></i> ${item.username}</p>
            </div>
            <button onclick="removeSaved('${item._id}')">Remove</button>
          </div>
        `;
      });
 
    };

  } catch (err) {
    container.innerHTML = "<p>Error loading saved items</p>";
    console.error(err);
  } finally {
    setTimeout(() => {
      loading.style.display = "none";
      container.style.display = "flex";
      document.body.style.overflowY = "auto";
    }, 500); 
  }
};

const removeSaved = async (id) => {
  try {
    const res = await fetch(`http://localhost:3000/api/user/save/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
    });
    if (!res.ok) return;
    loadSaved();
  } catch (err) {
    console.error(err);
  }
};

loadSaved();


const modal = document.getElementById("image-modal");
const modalImg = document.getElementById("modal-img");
const closeBtn = document.querySelector(".close");

document.addEventListener("click", (e) => {
  if (e.target.closest("button")) return;
  const img = e.target.closest("img");
  if (!img) return;
  modal.style.display = "flex";
  modalImg.src = img.src;
});

closeBtn.addEventListener("click", () => {
  modal.style.display = "none";
});

modal.addEventListener("click", (e) => {
  if (e.target === modal) modal.style.display = "none";
});