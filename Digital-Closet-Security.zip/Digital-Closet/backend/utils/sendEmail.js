const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  host: process.env.MAILTRAP_HOST,
  port: process.env.MAILTRAP_PORT,
  auth: {
    user: process.env.MAILTRAP_USER,
    pass: process.env.MAILTRAP_PASS,
  },
});

const sendResetCodeEmail = async (toEmail, code) => {
  await transporter.sendMail({
    from: '"Digital Closet" <noreply@digitalcloset.com>',
    to: toEmail,
    subject: "Your Password Reset Code",
    text: `Your password reset code is: ${code}\n\nThis code expires in 10 minutes.`,
    html: `<p>Your password reset code is: <b>${code}</b></p><p>This code expires in 10 minutes.</p>`,
  });
};

module.exports = sendResetCodeEmail;