const express = require("express");
const jwt = require("jsonwebtoken");
const sendResetCodeEmail = require("../utils/sendEmail");
const bcrypt = require("bcryptjs");
const mongoose = require("mongoose");
const User = require("../models/User");
const rateLimit = require("express-rate-limit");
const { ipKeyGenerator } = require("express-rate-limit");
const router = express.Router();

const loginLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 5,
  keyGenerator: (req) => {
    return ipKeyGenerator(req.ip) + ":" + (req.body.email || "unknown");
  },
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => {
    const remainingSeconds = Math.ceil(req.rateLimit.resetTime ? (req.rateLimit.resetTime - Date.now()) / 1000 : 300);
    res.status(429).json({
      success: false,
      message: "Too many login attempts from this device for this account.",
      remainingSeconds,
    });
  },
});

/* ================= REGISTER ================= */
router.post("/register", async (req, res) => {
  try {
    const { username, password } = req.body;
    const email = req.body.email.toLowerCase().trim();

    if (!username || !email || !password) {
      return res.status(400).json({
        success: false,
        message: "All fields are required",
      });
    }

    /* ===== SECURITY: PASSWORD STRENGTH ===== */
    const strongPasswordRegex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&.#_-])[A-Za-z\d@$!%*?&.#_-]{8,}$/;

    if (!strongPasswordRegex.test(password)) {
      return res.status(400).json({
        success: false,
        message:
          "Password must be at least 8 characters and include uppercase, lowercase, number, and special character.",
      });
    }

    const existingUser = await User.findOne({ email });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: "Email already exists",
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await User.create({
      username,
      email,
      password: hashedPassword,
      failedAttempts: 0,
      lockUntil: null,
    });

    res.status(201).json({
      success: true,
      message: "Registration successful",
      id: user._id,
    });
  } catch (err) {
    console.error("REGISTER ERROR:", err);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
});

/* ================= LOGIN ================= */
router.post("/login",  loginLimiter,  async (req, res) => {
  try {
    const { password } = req.body;
    const email = req.body.email.toLowerCase().trim();

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and password are required",
      });
    }

    const user = await User.findOne({ email });
    console.log("Trying to login:", email);

    if (!user) {
      return res.status(400).json({
        success: false,
        message: "User not found",
      });
    }
    console.log("Found user:", user.email);
    console.log("failedAttempts:", user.failedAttempts);
    console.log("lockUntil:", user.lockUntil);
    console.log("Now:", new Date());

    /* ===== SECURITY: ACCOUNT LOCK CHECK ===== */
    if (user.lockUntil && user.lockUntil > Date.now()) {
      const remainingSeconds = Math.ceil(
        (user.lockUntil - Date.now()) / 1000
      );

      return res.status(403).json({
        success: false,
        message: "Account locked.",
        remainingSeconds,
      });
    }
/* ===== SECURITY: RESET EXPIRED LOCK ===== */
if (user.lockUntil && user.lockUntil <= Date.now()) {
  user.failedAttempts = 0;
  user.lockUntil = null;
  await user.save();
}

const isMatch = await bcrypt.compare(password, user.password);

/* ===== SECURITY: FAILED LOGIN ATTEMPTS ===== */
if (!isMatch) {
  user.failedAttempts = (user.failedAttempts || 0) + 1;

  if (user.failedAttempts >= 5) {
    user.lockUntil = new Date(Date.now() + 5 * 60 * 1000);

    await user.save();

    return res.status(403).json({
      success: false,
      message: "Account locked.",
      remainingSeconds: Math.ceil(
        (user.lockUntil - Date.now()) / 1000
      ),
    });
  }

  await user.save();

  return res.status(400).json({
    success: false,
    message: `Incorrect password. Attempt ${user.failedAttempts}/5`,
  });
}

/* ===== SECURITY: SUCCESSFUL LOGIN RESET ===== */
user.failedAttempts = 0;
user.lockUntil = null;
await user.save();

const token = jwt.sign(
  { id: user._id, role: user.role },
  process.env.JWT_SECRET,
  { expiresIn: "1h" }
);

res.json({
  success: true,
  message: "Login successful",
  token,
  id: user._id,
  username: user.username,
  role: user.role,
});
  } catch (err) {
    console.error("LOGIN ERROR:", err);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
});

/* ================= GET USER BY ID ================= */
router.get("/user/:id", async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid user ID",
      });
    }

    const user = await User.findById(id).select("username email");

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    res.json({
      success: true,
      user,
    });
  } catch (err) {
    console.error("GET USER ERROR:", err);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
});

/* ================= REQUEST RESET CODE ================= */
router.post("/request-reset", async (req, res) => {
  try {
    const email = req.body.email.toLowerCase().trim();
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    user.resetCode = code;
    user.resetCodeExpires = new Date(Date.now() + 10 * 60 * 1000);
    await user.save();

    await sendResetCodeEmail(email, code);

    res.json({ success: true, message: "Reset code sent to your email" });
  } catch (err) {
    console.error("REQUEST RESET ERROR:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

/* ================= VERIFY CODE + RESET PASSWORD ================= */
router.put("/reset-password", async (req, res) => {
  try {
    const { code, password } = req.body;
    const email = req.body.email.toLowerCase().trim();

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    if (!user.resetCode || user.resetCode !== code) {
      return res.status(400).json({ success: false, message: "Invalid reset code" });
    }

    if (!user.resetCodeExpires || user.resetCodeExpires < Date.now()) {
      return res.status(400).json({ success: false, message: "Reset code expired" });
    }

    /* ===== SECURITY: PASSWORD STRENGTH ===== */
const strongPasswordRegex =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&.#_-])[A-Za-z\d@$!%*?&.#_-]{8,}$/;

if (!strongPasswordRegex.test(password)) {
  return res.status(400).json({
    success: false,
    message:
      "Password must be at least 8 characters and include uppercase, lowercase, number, and special character.",
  });
}



    const hashedPassword = await bcrypt.hash(password, 10);

    user.password = hashedPassword;
    user.resetCode = null;
    user.resetCodeExpires = null;
    user.failedAttempts = 0;
    user.lockUntil = null;
    await user.save();

    res.json({ success: true, message: "Password updated successfully" });
  } catch (err) {
    console.error("RESET PASSWORD ERROR:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});


module.exports = router;
